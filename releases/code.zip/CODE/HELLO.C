/* Open Watcom DOS console example. F4 builds; F5 builds and runs. */
#include <conio.h>
#include <graph.h>

int main(void)
{
  _clearscreen(_GCLEARSCREEN);
  _settextcolor(14);
  cprintf("Hello from CODE!\r\n");
  _settextcolor(11);
  cprintf("MS-DOS, C and conio.h - press any key.\r\n");
  getch();
  _settextcolor(7);
  return 0;
}
