# RC low-pass filter: edit the component values, then press F9.
R = 10000;
C = 0.0000001;
f = 1000;
tau = R*C
fc = 1/(2*pi*tau)
wRC = 2*pi*f*tau;
magnitude = 1/sqrt(1+wRC^2)
gain_dB = 20*log(magnitude,10)
phase_deg = -atan(wRC)*180/pi
print "tau: seconds; fc: Hz; gain: dB; phase: degrees"
