# Run: CMATH CMATH\DEMO.M 2 3
print "Script inputs:"
x = $input1 + $input2
print "Matrix multiplication:"
A = [1,2;3,4];
A*A
print "Element-wise square:"
A.^2
print "Final result:"
return x*2
