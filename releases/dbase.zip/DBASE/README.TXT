DBASE modem demonstration
=========================
From the BUILD directory, run DBASE DBASE\MODEMS.DB.
Use Tab to switch between Tables and Records. Press Enter to open a record,
F7 to add one, and F9 to apply changes in the form or save in the browser.
Press F1 for help. Select device 1, press F5 and choose device 2 to compare. The two device profiles are fictional and illustrate associations,
inherited values, overrides and missing support records.

MODEMS.DB is the ready-to-open database. MODEMS.JSN is its JSON snapshot.
See SOURCE/DBASE/README.md in the repository for the complete guide.
