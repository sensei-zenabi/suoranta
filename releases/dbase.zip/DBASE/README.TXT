DBASE - Library catalog example
================================

From the extracted folder run:

    DBASE DBASE\LIBRARY.DB

AUTHORS and BOOKS hold fictional catalog entries. CREDITS links
books to their authors, including books with more than one author.

Select an author, then use F6 and choose Browse related records.
In Records, use Left and Right to switch records, and Up and Down
to scroll. PgUp and PgDn scroll by a page. Table Design lets you
set the rows reserved for each field with Preview Height.

Press F9 to save the catalog as DBASE\LIBRARY.BDB. Press F1 for help.
