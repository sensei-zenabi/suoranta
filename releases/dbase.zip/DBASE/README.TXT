DBASE - Library catalog example
================================

From the extracted folder run:

    DBASE DBASE\LIBRARY.DB

AUTHORS and BOOKS hold the catalog entries. CREDITS links each book
to its author or authors. All entries are fictional.

Select an author, then use F6 and choose Browse related records to
find books in the catalog. Press F1 for help.

In Records, use Left and Right to switch records and Up and Down to
scroll one row at a time. PgUp and PgDn scroll by a page. Wrapping
starts on and reserves each field's Preview Height plus a blank row
between fields. In Table Design, press Enter on a field to set its
Preview Height.
