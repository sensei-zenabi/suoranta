DBASE - Library catalog example
================================

From the extracted folder run:

    DBASE DBASE\LIBRARY.DB

AUTHORS and BOOKS hold the catalog entries. CREDITS links each book
to its author or authors. All entries are fictional.

Select an author, then use F6 and choose Browse related records to
find books in the catalog. Press F1 for help.

The Records pane shows one record at a time. Use Up and Down to switch
records. Use PgUp and PgDn to scroll long previews. In Table Design,
press Enter on a field and choose Preview Height to set its row limit.
