DBASE - Library catalog example
================================

From the extracted folder run:

    DBASE DBASE\LIBRARY.DB

AUTHORS and BOOKS hold the catalog entries. CREDITS links each book
to its author or authors. All entries are fictional.

Select an author, then use F6 and choose Browse related records to
find books in the catalog. Press F1 for help.

LIBRARY.JSN is the editable exchange file. To rebuild the sample
database under a different name, run:

    DBASE /IMPORT COPY.DB /FORMAT JSON /IN DBASE\LIBRARY.JSN
